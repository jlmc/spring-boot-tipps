package io.costax.demo.domain.model;

public enum Permission {

    ADMIN, CLIENT

}
